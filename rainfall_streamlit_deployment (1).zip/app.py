
import os
import streamlit as st

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain

st.set_page_config(
    page_title="Rainfall Research Assistant",
    page_icon="🌧️",
    layout="wide"
)

st.title("🌧️ Rainfall Research Assistant")
st.caption("Ask questions about the research paper: Development of Multiple Combined Regression Methods for Rainfall Measurement.")

@st.cache_resource
def load_rag():
    db_path = os.path.join(os.path.dirname(__file__), "rainfall_chroma_db")

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vectorstore = Chroma(
        persist_directory=db_path,
        collection_name="rainfall_research_v2",
        embedding_function=embeddings
    )

    retriever = vectorstore.as_retriever(
        search_kwargs={"k": 12}
    )

    llm = ChatGroq(
        model="openai/gpt-oss-120b",
        temperature=0.2,
        max_tokens=1200,
        groq_api_key=st.secrets["GROQ_API_KEY"]
    )

    document_prompt = PromptTemplate(
        input_variables=["page_content", "page"],
        template="PDF PAGE: {page}\nDOCUMENT CONTENT:\n{page_content}"
    )

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            """You are a precise research assistant answering questions
            using the supplied rainfall research paper context.

            Follow these rules:
            1. Read all retrieved context before answering.
            2. Search across all supplied chunks for the answer.
            3. Combine information from continuation chunks when needed.
            4. For tables, match each value to the correct model and metric.
            5. Preserve exact numerical values from the paper.
            6. Include the PDF page number for factual answers.
            7. If the paper does not provide the answer, clearly say so.
            8. Never invent facts, values, hardware details, or experiments.
            9. If the paper contains conflicting statements, explain the
               discrepancy instead of silently choosing one.
            10. For model comparisons, consider every relevant row provided.

            Research context:
            {context}"""
        ),
        ("human", "{input}")
    ])

    document_chain = create_stuff_documents_chain(
        llm,
        prompt,
        document_prompt=document_prompt
    )

    return create_retrieval_chain(retriever, document_chain)

try:
    rag_chain = load_rag()
    st.success("Research database loaded successfully.")
except Exception as e:
    st.error(f"Could not load the chatbot: {e}")
    st.stop()

if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    st.subheader("About this chatbot")
    st.write("Answers are generated from the rainfall research paper and its indexed document database.")
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

question = st.chat_input("Ask a question about the rainfall research paper...")

if question:
    st.session_state.messages.append({
        "role": "user",
        "content": question
    })

    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Searching the research paper..."):
            try:
                response = rag_chain.invoke({"input": question})
                answer = response["answer"]
                st.markdown(answer)

                source_docs = response.get("context", [])
                if source_docs:
                    with st.expander("View retrieved sources"):
                        seen = set()
                        for doc in source_docs:
                            page = doc.metadata.get("page")
                            source = doc.metadata.get("source", "Research paper")
                            key = (source, page, doc.page_content[:100])

                            if key not in seen:
                                seen.add(key)
                                st.markdown(
                                    f"**Source:** {source} | "
                                    f"**PDF page:** {page}"
                                )
                                st.caption(doc.page_content[:500])

                st.session_state.messages.append({
                    "role": "assistant",
                    "content": answer
                })

            except Exception as e:
                st.error(f"An error occurred: {e}")
